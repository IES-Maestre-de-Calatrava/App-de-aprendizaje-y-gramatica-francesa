package grammou.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/ejercicios")
public class FormController {

    @Autowired
    private RegistroRepository registroRepository;

    private static final String CARPETA_UPLOADS = "uploads/";

    @PostMapping("/upload")
    public ResponseEntity<Map<String, Object>> subirRegistro(
            @RequestParam("archivo") MultipartFile archivo,
            @RequestParam("nombre") String nombre,
            @RequestParam("nivel") String nivel,
            @RequestParam("enlace") String enlace,
            @RequestParam(value = "descripcion", required = false) String descripcion) {

        Map<String, Object> respuesta = new HashMap<>();

        try {
            // 1. Crear carpeta si no existe
            File carpeta = new File(CARPETA_UPLOADS);
            if (!carpeta.exists()) {
                carpeta.mkdirs();
            }

            // 2. Guardar archivo físico
            File destino = new File(carpeta.getAbsolutePath() + File.separator + enlace);
            archivo.transferTo(destino);

            // 3. Guardar en Base de Datos
            Registro reg = new Registro();
            reg.setNombre(nombre);
            reg.setNivel(nivel);
            reg.setEnlace(enlace);
            reg.setDescripcion(descripcion);
            reg.setPuntos(0);
            reg.setHoraSubida(LocalDateTime.now());

            registroRepository.save(reg);

            respuesta.put("success", true);
            respuesta.put("mensaje", "Subido correctamente");
            return ResponseEntity.ok(respuesta);

        } catch (Exception e) {
            System.err.println("ERROR EN SUBIDA: " + e.getMessage());
            respuesta.put("success", false);
            respuesta.put("mensaje", "Error interno: " + e.getMessage());
            return ResponseEntity.status(500).body(respuesta);
        }
    }

    @GetMapping
    public ResponseEntity<List<Registro>> obtenerTodos() {
        return ResponseEntity.ok(registroRepository.findAll());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> eliminar(@PathVariable Long id) {
        Map<String, Object> respuesta = new HashMap<>();
        try {
            Registro reg = registroRepository.findById(id).orElseThrow();
            File f = new File(CARPETA_UPLOADS + reg.getEnlace());
            if (f.exists()) f.delete();
            
            registroRepository.deleteById(id);
            respuesta.put("success", true);
            return ResponseEntity.ok(respuesta);
        } catch (Exception e) {
            respuesta.put("success", false);
            return ResponseEntity.status(500).body(respuesta);
        }
    }
}