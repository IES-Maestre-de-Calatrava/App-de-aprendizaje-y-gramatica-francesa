package grammou.demo;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;

@Entity
@Table(name = "EJERCICIO")
public class Registro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_EJERCICIO")
    private Long id;

    @Column(name = "NOMBRE")
    private String nombre;

    @Column(name = "NIVEL")
    private String nivel;

    @Column(name = "ENLACE")
    private String enlace;

    @Column(name = "DESCRIPCION")
    private String descripcion;

    @Column(name = "PUNTOS")
    private Integer puntos;

    @Column(name = "HORA_SUBIDA")
    @JsonProperty("fechaCreacion") // Esto arregla el error de visualización en el JS
    private LocalDateTime horaSubida;

    // --- GETTERS Y SETTERS ---
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getNivel() { return nivel; }
    public void setNivel(String nivel) { this.nivel = nivel; }
    public String getEnlace() { return enlace; }
    public void setEnlace(String enlace) { this.enlace = enlace; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public Integer getPuntos() { return puntos; }
    public void setPuntos(Integer puntos) { this.puntos = puntos; }
    public LocalDateTime getHoraSubida() { return horaSubida; }
    public void setHoraSubida(LocalDateTime horaSubida) { this.horaSubida = horaSubida; }
}