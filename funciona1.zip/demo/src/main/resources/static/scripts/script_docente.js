/* ============================================================
   script.js  —  Panel Docente · GRAMMOÙ

   Controla toda la lógica del panel del docente:

   SECCIÓN 1  → CONFIGURACIÓN Y REFERENCIAS AL DOM
   SECCIÓN 2  → DRAG & DROP (arrastrar archivos)
   SECCIÓN 3  → SELECTOR DE NIVEL (botones A1/A2/B1/B2)
   SECCIÓN 4  → CONTADOR DE CARACTERES
   SECCIÓN 5  → SUBIDA DEL ARCHIVO AL SERVIDOR (fetch + FormData)
   SECCIÓN 6  → CARGAR Y MOSTRAR LISTA DE EJERCICIOS
   SECCIÓN 7  → FILTROS POR NIVEL
   SECCIÓN 8  → ELIMINAR EJERCICIO
   SECCIÓN 9  → ALERTAS FLOTANTES
   SECCIÓN 10 → FUNCIONES AUXILIARES
   SECCIÓN 11 → DATOS DE DEMO (temporales hasta tener el servidor)
   SECCIÓN 12 → INICIO
   ============================================================ */


/* ============================================================
   SECCIÓN 1 — CONFIGURACIÓN Y REFERENCIAS AL DOM

   API_BASE: URL base del servidor.
   ⚠️ ÚNICO CAMBIO NECESARIO cuando Tomcat esté levantado:
      Sustituir 'http://localhost:8080/api' por la IP real.
      Ej: 'http://192.168.1.45:8080/api'

   Las referencias al DOM guardan en variables los elementos
   HTML que usamos en múltiples sitios del código.
   Es más eficiente que llamar a getElementById() cada vez.
   ============================================================ */

const API_BASE = 'http://localhost:8080/api';

/* — Zona de subida — */
const dropzone        = document.getElementById('dropzone');
const inputArchivo    = document.getElementById('h5p-file');
const fileNameDisplay = document.getElementById('file-name-display');

/* — Campos del formulario — */
const inputNombre  = document.getElementById('nombre');
const inputDesc    = document.getElementById('descripcion');
const charCount    = document.getElementById('char-count');
const nivelGroup   = document.getElementById('nivel-group');
const nivelHidden  = document.getElementById('nivel-hidden');

/* — Barra de progreso y botón — */
const btnSubir     = document.getElementById('btn-subir');
const progressWrap = document.getElementById('upload-progress-wrap');
const progressBar  = document.getElementById('progress-bar');
const progressPct  = document.getElementById('progress-pct');

/* — Lista de ejercicios — */
const ejerciciosList = document.getElementById('ejercicios-list');
const loadingList    = document.getElementById('loading-list');
const emptyState     = document.getElementById('empty-state');
const btnRefresh     = document.getElementById('btn-refresh');
const navCount       = document.getElementById('nav-count');
const filtrosNivel   = document.getElementById('filtros-nivel');

/* — Alertas — */
const alertBox = document.getElementById('alert-box');

/*
   Variable global para el archivo elegido por el docente.
   Empieza en null: aún no se ha elegido ninguno.
   Se actualiza en procesarArchivo() cuando el docente elige uno.
*/
let archivoSeleccionado = null;


/* ============================================================
   SECCIÓN 2 — DRAG & DROP

   Permite arrastrar un .h5p sobre la zona punteada.
   También funciona haciendo clic porque el input invisible
   ocupa toda la zona del dropzone.

   Eventos del navegador:
     dragover  → archivo encima  → cambiar estilo visual
     dragleave → archivo sale    → quitar estilo visual
     drop      → archivo soltado → recogerlo
     change    → elegido con clic del SO → recogerlo
   ============================================================ */

/*
   Cancelamos el comportamiento nativo del navegador (abriría el
   archivo) y añadimos 'dragover' para cambiar el borde a azul.
*/
dropzone.addEventListener('dragover', function(evento) {
    evento.preventDefault();
    dropzone.classList.add('dragover');
});

/* Al salir sin soltar, quitamos el estilo visual */
dropzone.addEventListener('dragleave', function() {
    dropzone.classList.remove('dragover');
});

/*
   Al soltar el archivo, evento.dataTransfer.files contiene
   los archivos arrastrados. Solo tomamos el primero [0].
*/
dropzone.addEventListener('drop', function(evento) {
    evento.preventDefault();
    dropzone.classList.remove('dragover');
    if (evento.dataTransfer.files.length > 0) {
        procesarArchivo(evento.dataTransfer.files[0]);
    }
});

/* Cuando el docente elige el archivo desde el explorador del SO */
inputArchivo.addEventListener('change', function() {
    if (inputArchivo.files.length > 0) {
        procesarArchivo(inputArchivo.files[0]);
    }
});

/*
   procesarArchivo()

   Valida que sea .h5p y muestra el nombre en la interfaz.

   @param {File} archivo — objeto File del navegador
*/
function procesarArchivo(archivo) {

    /* Validar extensión */
    if (!archivo.name.toLowerCase().endsWith('.h5p')) {
        mostrarAlerta('Solo se aceptan archivos con extensión .h5p', 'danger');
        return;
    }

    /* Guardar en la variable global para usarlo al subir */
    archivoSeleccionado = archivo;

    /* Mostrar el nombre del archivo en la interfaz */
    fileNameDisplay.textContent = archivo.name;
    fileNameDisplay.style.color = 'var(--french-blue)';
}


/* ============================================================
   SECCIÓN 3 — SELECTOR DE NIVEL

   Los botones A1/A2/B1/B2 son <button>, no inputs normales.
   Usamos "delegación de eventos": un listener en el contenedor
   (#nivel-group) en lugar de uno por botón. Es más eficiente
   y funciona aunque los botones se creen dinámicamente.

   Al hacer clic:
     1. Quitamos 'selected' de todos
     2. Añadimos 'selected' al clickado
     3. Guardamos el valor en el input hidden
   ============================================================ */

nivelGroup.addEventListener('click', function(evento) {

    /*
       closest() sube por el DOM desde donde se hizo clic
       hasta encontrar el elemento con esa clase
    */
    const boton = evento.target.closest('.nivel-btn');
    if (!boton) return;

    /* Quitar selección de todos */
    nivelGroup.querySelectorAll('.nivel-btn').forEach(function(btn) {
        btn.classList.remove('selected');
    });

    /* Marcar el clickado */
    boton.classList.add('selected');

    /*
       Guardar el valor (data-nivel="A1" → nivelHidden.value = "A1")
       para que FormData lo pueda enviar al servidor
    */
    nivelHidden.value = boton.dataset.nivel;
});


/* ============================================================
   SECCIÓN 4 — CONTADOR DE CARACTERES

   El evento 'input' se dispara con cada tecla pulsada.
   Actualizamos el número visible en tiempo real.
   ============================================================ */

inputDesc.addEventListener('input', function() {
    charCount.textContent = inputDesc.value.length;
});


/* ============================================================
   SECCIÓN 5 — SUBIDA DEL ARCHIVO AL SERVIDOR

   Usamos fetch() con POST.

   ¿Qué es FormData?
   Un objeto del navegador que empaqueta texto y archivos
   binarios juntos, igual que un formulario HTML normal.

   ¿Por qué NO ponemos Content-Type?
   Con FormData el navegador añade automáticamente
   "multipart/form-data" con el boundary correcto.
   Si lo ponemos manualmente el servidor no puede leer el archivo.

   ¿Qué es async/await?
   Forma moderna de esperar respuestas sin bloquear la página.
   El código se lee de arriba a abajo como si fuera síncrono.

   Campo 'enlace':
   La BD tiene una columna 'enlace' donde guardamos el nombre
   del archivo .h5p. El servidor lo guarda en MySQL con ese nombre.
   ============================================================ */

btnSubir.addEventListener('click', async function() {

    /* ── PASO 1: VALIDAR CAMPOS ──────────────────────────────── */

    if (!archivoSeleccionado) {
        mostrarAlerta('Selecciona un archivo .h5p antes de subir.', 'warning');
        return;
    }

    /* trim() elimina espacios al inicio y al final */
    if (inputNombre.value.trim() === '') {
        mostrarAlerta('El nombre del ejercicio es obligatorio.', 'warning');
        inputNombre.focus();
        return;
    }

    if (nivelHidden.value === '') {
        mostrarAlerta('Selecciona el nivel del ejercicio.', 'warning');
        return;
    }

    /* ── PASO 2: CREAR FORMDATA ──────────────────────────────── */

    /*
       append(nombreCampo, valor) añade cada campo al paquete.
       El servidor Spring Boot los recibe con @RequestParam:

         @RequestParam("archivo")     MultipartFile archivo
         @RequestParam("nombre")      String nombre
         @RequestParam("nivel")       String nivel
         @RequestParam("enlace")      String enlace
         @RequestParam("descripcion") String descripcion (opcional)
    */
    const formData = new FormData();
    formData.append('archivo', archivoSeleccionado);         // Archivo binario .h5p
    formData.append('nombre',  inputNombre.value.trim());    // Ej: "Les articles définis"
    formData.append('nivel',   nivelHidden.value);           // Ej: "A1"
    formData.append('enlace',  archivoSeleccionado.name);    // Nombre del archivo → columna 'enlace' en BD

    /* Descripción es opcional */
    if (inputDesc.value.trim() !== '') {
        formData.append('descripcion', inputDesc.value.trim());
    }

    /* ── PASO 3: PREPARAR LA INTERFAZ ────────────────────────── */

    /* Deshabilitar botón para evitar doble envío */
    btnSubir.disabled  = true;
    btnSubir.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>Subiendo…';

    /* Mostrar barra de progreso */
    progressWrap.style.display = 'block';
    actualizarProgreso(30); /* fetch() no da % real → progreso simulado */

    /* ── PASO 4: ENVIAR CON fetch() ──────────────────────────── */

    try {
        actualizarProgreso(60);

        /*
           fetch(url, opciones):
             method: 'POST' → enviamos datos al servidor
             body: formData  → datos empaquetados
           await pausa aquí hasta recibir respuesta.
        */
        const respuesta = await fetch(`${API_BASE}/ejercicios/upload`, {
            method: 'POST',
            body:   formData
            /* ⚠️ Sin Content-Type — el navegador lo gestiona solo */
        });

        /* ── PASO 5: LEER LA RESPUESTA ───────────────────────── */

        /*
           respuesta.ok    → true si código HTTP 200-299
           respuesta.json() → convierte JSON del servidor en objeto JS
        */
        const datos = await respuesta.json();

        if (respuesta.ok) {

            /* ── ÉXITO ──────────────────────────────────────── */
            actualizarProgreso(100);
            mostrarAlerta('Ejercicio subido correctamente.', 'success');
            limpiarFormulario();
            cargarEjercicios(); /* Recargar lista para ver el nuevo */

        } else {

            /* ── ERROR DEL SERVIDOR (400, 500...) ──────────── */
            const mensajeError = datos.mensaje || 'Error al subir el ejercicio.';
            mostrarAlerta(mensajeError, 'danger');
            actualizarProgreso(0);
        }

    } catch (error) {

        /* ── ERROR DE RED (sin conexión, servidor caído) ────── */
        console.error('Error de red:', error);
        mostrarAlerta('Error de red. Comprueba que el servidor está activo.', 'danger');
        actualizarProgreso(0);

    } finally {

        /*
           finally se ejecuta SIEMPRE, haya error o no.
           Garantiza que el botón siempre se restaura.
        */
        restaurarBotonSubir();
    }
});


/* ============================================================
   SECCIÓN 6 — CARGAR Y MOSTRAR LISTA DE EJERCICIOS

   Petición GET al servidor para obtener la lista de ejercicios.

   GET  → obtener datos (sin modificar nada en el servidor)
   POST → enviar datos nuevos
   DELETE → eliminar datos
   ============================================================ */

/*
   cargarEjercicios()

   Pide la lista al servidor y llama a renderizarLista().
   Si el servidor no responde, usa getDatosDemo() para desarrollo.
*/
async function cargarEjercicios() {

    mostrarEstado('loading');

    try {
        /*
           fetch() sin opciones hace GET por defecto.
           await espera la respuesta del servidor.
        */
        const respuesta = await fetch(`${API_BASE}/ejercicios`);

        if (!respuesta.ok) {
            throw new Error(`Error del servidor: ${respuesta.status}`);
        }

        /*
           respuesta.json() convierte el JSON del servidor en array JS.
           El servidor devolverá algo como:
           [
             { id: 1, nombre: "Les articles", nivel: "A1",
               enlace: "articles.h5p", fechaCreacion: "2026-04-10T..." },
             ...
           ]
        */
        const ejercicios = await respuesta.json();
        renderizarLista(ejercicios);

    } catch (error) {

        /*
           Si el servidor no está disponible, usamos datos de demo.
           Cuando Tomcat esté levantado, este bloque no se ejecutará.
        */
        console.warn('Servidor no disponible — usando datos de demo:', error);
        renderizarLista(getDatosDemo());
    }
}

/*
   renderizarLista()

   Recibe el array de ejercicios y construye la lista.

   @param {Array} ejercicios — array de objetos del servidor
*/
function renderizarLista(ejercicios) {

    /* Actualizar el contador del nav */
    navCount.textContent = ejercicios.length;

    if (ejercicios.length === 0) {
        mostrarEstado('empty');
        return;
    }

    mostrarEstado('list');
    ejerciciosList.innerHTML = ''; /* Limpiar contenido previo */

    /* Crear tarjeta por cada ejercicio y añadirla a la lista */
    ejercicios.forEach(function(ejercicio) {
        const item = crearTarjetaEjercicio(ejercicio);
        ejerciciosList.appendChild(item);
    });
}

/*
   crearTarjetaEjercicio()

   Construye la tarjeta HTML de un ejercicio.
   Muestra: icono, nombre, enlace (nombre del archivo), fecha,
            badge de nivel y botón eliminar.

   @param {Object} ejercicio — datos del ejercicio
   @returns {HTMLElement}
*/
function crearTarjetaEjercicio(ejercicio) {

    const item = document.createElement('div');
    item.className     = 'ejercicio-item';
    item.dataset.nivel = ejercicio.nivel; /* Para los filtros */

    /*
       Template literal: combina HTML con variables JS en ${ }
       ejercicio.enlace → nombre del archivo guardado en BD
    */
    item.innerHTML = `
        <div class="ejercicio-icon">
            <i class="bi bi-file-earmark-play"></i>
        </div>
        <div class="ejercicio-info">
            <div class="name">${truncar(ejercicio.nombre, 40)}</div>
            <div class="meta">
                <i class="bi bi-link-45deg"></i> ${ejercicio.enlace}
                &nbsp;·&nbsp;
                ${formatearFecha(ejercicio.fechaCreacion)}
            </div>
        </div>
        <span class="nivel-badge nivel-${ejercicio.nivel}">
            ${ejercicio.nivel}
        </span>
        <button class="btn-delete"
                title="Eliminar ejercicio"
                aria-label="Eliminar ${ejercicio.nombre}">
            <i class="bi bi-trash"></i>
        </button>
    `;

    /* Evento de eliminar para este item concreto */
    item.querySelector('.btn-delete').addEventListener('click', function() {
        eliminarEjercicio(ejercicio.id, ejercicio.nombre, item);
    });

    return item;
}


/* ============================================================
   SECCIÓN 7 — FILTROS POR NIVEL

   Muestra u oculta tarjetas según su nivel sin nueva petición
   al servidor. Usamos el data-nivel de cada tarjeta.
   ============================================================ */

filtrosNivel.addEventListener('click', function(evento) {

    const boton = evento.target.closest('.nivel-btn');
    if (!boton || !boton.dataset.filter) return;

    const filtro = boton.dataset.filter; /* "all", "A1", "A2"... */

    /* Actualizar estilo de los botones de filtro */
    filtrosNivel.querySelectorAll('.nivel-btn').forEach(function(btn) {
        btn.classList.remove('selected');
    });
    boton.classList.add('selected');

    /* Mostrar u ocultar cada tarjeta según su data-nivel */
    ejerciciosList.querySelectorAll('.ejercicio-item').forEach(function(item) {
        const visible = filtro === 'all' || item.dataset.nivel === filtro;
        item.style.display = visible ? '' : 'none';
    });
});


/* ============================================================
   SECCIÓN 8 — ELIMINAR EJERCICIO

   Petición DELETE al servidor con el ID del ejercicio.
   Si el servidor confirma el borrado, eliminamos la tarjeta
   del DOM con animación sin recargar la página.
   ============================================================ */

/*
   eliminarEjercicio()

   @param {number} id       — ID del ejercicio en la BD
   @param {string} nombre   — nombre para la confirmación
   @param {HTMLElement} item — tarjeta a eliminar del DOM
*/
async function eliminarEjercicio(id, nombre, item) {

    /* confirm() muestra un diálogo nativo del navegador */
    const confirmado = confirm(`¿Eliminar "${nombre}"?\nEsta acción no se puede deshacer.`);
    if (!confirmado) return;

    try {
        /*
           DELETE http://localhost:8080/api/ejercicios/{id}
           El ID en la URL indica al servidor qué ejercicio borrar.
        */
        const respuesta = await fetch(`${API_BASE}/ejercicios/${id}`, {
            method: 'DELETE'
        });

        if (respuesta.ok) {

            /* Animación de desaparición antes de quitar del DOM */
            item.style.transition = 'opacity 0.3s';
            item.style.opacity    = '0';

            setTimeout(function() {
                item.remove();

                /* Si ya no quedan, mostrar estado vacío */
                if (ejerciciosList.querySelectorAll('.ejercicio-item').length === 0) {
                    mostrarEstado('empty');
                }

                /* Decrementar contador del nav */
                navCount.textContent = Math.max(0, parseInt(navCount.textContent) - 1);
            }, 300);

            mostrarAlerta(`"${nombre}" eliminado correctamente.`, 'success');

        } else {
            mostrarAlerta('No se pudo eliminar el ejercicio.', 'danger');
        }

    } catch (error) {
        console.error('Error al eliminar:', error);
        mostrarAlerta('Error de red al intentar eliminar.', 'danger');
    }
}


/* ============================================================
   SECCIÓN 9 — ALERTAS FLOTANTES

   Mensajes en la esquina superior derecha.
   Se cierran solos a los 4 segundos o manualmente con la X.

   Tipos:
     'success' → verde  | 'danger'  → rojo
     'warning' → naranja | 'info'   → azul
   ============================================================ */

/*
   mostrarAlerta()

   @param {string} mensaje — texto a mostrar
   @param {string} tipo    — 'success' | 'danger' | 'warning' | 'info'
*/
function mostrarAlerta(mensaje, tipo) {

    const iconos = {
        success: 'bi-check-circle-fill',
        danger:  'bi-x-circle-fill',
        warning: 'bi-exclamation-triangle-fill',
        info:    'bi-info-circle-fill'
    };

    const alerta = document.createElement('div');
    alerta.className = `alert alert-${tipo} alert-custom alert-dismissible fade show`;
    alerta.innerHTML = `
        <i class="bi ${iconos[tipo] || 'bi-info-circle-fill'}"></i>
        <span>${mensaje}</span>
        <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
    `;

    alertBox.appendChild(alerta);

    /* Desaparecer automáticamente en 4 segundos */
    setTimeout(function() {
        alerta.classList.remove('show');
        setTimeout(function() { alerta.remove(); }, 300);
    }, 4000);
}


/* ============================================================
   SECCIÓN 10 — FUNCIONES AUXILIARES

   Funciones reutilizables que evitan repetir código
   (principio DRY: Don't Repeat Yourself).
   ============================================================ */

/*
   actualizarProgreso()
   Con fetch() el progreso es simulado (30 → 60 → 100)
   porque fetch no expone el porcentaje de subida.

   @param {number} porcentaje — 0 a 100
*/
function actualizarProgreso(porcentaje) {
    progressBar.style.width = porcentaje + '%';
    progressBar.setAttribute('aria-valuenow', porcentaje);
    progressPct.textContent = porcentaje + '%';
}

/*
   restaurarBotonSubir()
   Restaura el botón y oculta la barra.
   Se llama en finally para garantizar que siempre ocurre.
*/
function restaurarBotonSubir() {
    btnSubir.disabled  = false;
    btnSubir.innerHTML = '<i class="bi bi-cloud-upload me-2"></i>Subir ejercicio';
    progressWrap.style.display = 'none';
}

/*
   limpiarFormulario()
   Resetea todos los campos tras una subida exitosa.
*/
function limpiarFormulario() {
    archivoSeleccionado         = null;
    inputArchivo.value          = '';
    fileNameDisplay.textContent = 'Ningún archivo seleccionado';
    fileNameDisplay.style.color = '';
    inputNombre.value           = '';
    inputDesc.value             = '';
    charCount.textContent       = '0';
    nivelHidden.value           = '';
    nivelGroup.querySelectorAll('.nivel-btn').forEach(function(btn) {
        btn.classList.remove('selected');
    });
}

/*
   mostrarEstado()
   Controla qué bloque es visible en la columna derecha.

   'loading' → spinner
   'list'    → lista de ejercicios
   'empty'   → mensaje sin ejercicios

   @param {string} estado
*/
function mostrarEstado(estado) {
    loadingList.style.display    = estado === 'loading' ? 'block' : 'none';
    ejerciciosList.style.display = estado === 'list'    ? 'flex'  : 'none';
    emptyState.style.display     = estado === 'empty'   ? 'block' : 'none';
}

/*
   truncar()
   Recorta texto largo para no romper el diseño.

   @param {string} texto
   @param {number} maxLength
   @returns {string}
*/
function truncar(texto, maxLength) {
    return texto.length > maxLength
        ? texto.slice(0, maxLength) + '…'
        : texto;
}

/*
   formatearFecha()
   ISO → fecha legible en español.
   "2026-04-10T10:00:00" → "10 abr 2026"

   @param {string} iso
   @returns {string}
*/
function formatearFecha(iso) {
    try {
        return new Date(iso).toLocaleDateString('es-ES', {
            day:   '2-digit',
            month: 'short',
            year:  'numeric'
        });
    } catch {
        return iso;
    }
}


/* ============================================================
   SECCIÓN 11 — DATOS DE DEMO

   ⚠️ SOLO PARA DESARROLLO — eliminar cuando Tomcat esté listo.

   Cuando fetch() falla (servidor no disponible) cargarEjercicios()
   usa estos datos para que la interfaz se pueda ver y probar.

   Los campos simulan exactamente lo que devolverá el servidor:
     id            → clave primaria de la BD
     nombre        → nombre del ejercicio
     nivel         → A1 / A2 / B1 / B2
     enlace        → nombre del archivo .h5p (columna 'enlace' en BD)
     fechaCreacion → timestamp de cuándo se subió
   ============================================================ */

function getDatosDemo() {
    return [
        {
            id: 1,
            nombre: 'Les articles définis',
            nivel: 'A1',
            enlace: 'articles_definis.h5p',
            fechaCreacion: '2026-04-10T10:00:00'
        },
        {
            id: 2,
            nombre: "Le présent de l'indicatif",
            nivel: 'A2',
            enlace: 'present_indicatif.h5p',
            fechaCreacion: '2026-04-15T11:30:00'
        },
        {
            id: 3,
            nombre: 'Imparfait vs passé composé',
            nivel: 'B1',
            enlace: 'imparfait_passe.h5p',
            fechaCreacion: '2026-04-22T09:00:00'
        }
    ];
}


/* ============================================================
   SECCIÓN 12 — INICIO

   Se ejecuta al terminar de cargar el HTML (el <script> está
   al final del body, por eso el DOM ya existe aquí).

   1. Botón "Actualizar" → recarga la lista manualmente
   2. cargarEjercicios() → primera carga al abrir la página
   ============================================================ */

btnRefresh.addEventListener('click', cargarEjercicios);

cargarEjercicios();