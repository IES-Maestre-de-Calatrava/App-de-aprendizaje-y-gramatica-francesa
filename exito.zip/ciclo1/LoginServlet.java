import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String user = request.getParameter("user");
        String pass = request.getParameter("pass");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/tu_basedatos",
                "root",
                "tu_password"
            );

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM usuarios WHERE username=? AND password=?"
            );

            ps.setString(1, user);
            ps.setString(2, pass);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                out.println("LOGIN OK");
            } else {
                out.println("LOGIN FAIL");
            }

            con.close();

        } catch (Exception e) {
            out.println("ERROR: " + e.getMessage());
        }
    }
}