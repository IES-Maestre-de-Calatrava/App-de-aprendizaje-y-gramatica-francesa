package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class FormController {

    @Autowired
    private RegistroRepository registroRepository;

    @PostMapping("/enviar")
    public String guardarDatos(@RequestParam("dato") String valorRecibido) {
        // 1. Creamos un objeto de la clase que hiciste antes
        Registro nuevoRegistro = new Registro();
        
        // 2. Le metemos el dato que viene del HTML
        nuevoRegistro.setDato(valorRecibido);
        
        // 3. Lo guardamos en MySQL
        registroRepository.save(nuevoRegistro);
        
        // 4. Recargamos la página o redirigimos (puedes crear un exito.html si quieres)
        return "redirect:/index.html";
    }
}